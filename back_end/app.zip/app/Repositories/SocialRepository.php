<?php

namespace App\Repositories;

use App\Interfaces\SocialInterface;


class SocialRepository implements SocialInterface
{
    public function index()
    {

    }

    public function getdata()
    {
    }

    public function show($id)
    {
    }

    public function create()
    {
    }
    public function store($request)
    {
    }

    public function delete($id)
    {
    }

}
