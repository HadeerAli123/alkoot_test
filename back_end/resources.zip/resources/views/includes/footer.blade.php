
<footer class="footer style--two text-center">
    لوحة التحكم &copy; 2025. جميع الحقوق محفوظة.
</footer>
<!-- ======= BEGIN GLOBAL MANDATORY SCRIPTS ======= -->
<!-- <script src=" {{ asset('assets/js/jquery.min.js')}}"></script> -->
<script src=" {{ asset('assets/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
<script src=" {{ asset('assets/plugins/perfect-scrollbar/perfect-scrollbar.min.js')}}"></script>
<script src=" {{ asset('assets/js/script.js')}}"></script>
<!-- ======= BEGIN GLOBAL MANDATORY SCRIPTS ======= -->

<!-- ======= BEGIN PAGE LEVEL PLUGINS/CUSTOM SCRIPTS ======= -->
<script src=" {{ asset('assets/plugins/apex/apexcharts.min.js')}}"></script>
<script src=" {{ asset('assets/plugins/apex/custom-apexcharts.js')}}"></script>
<!-- ======= End BEGIN PAGE LEVEL PLUGINS/CUSTOM SCRIPTS ======= -->

<!-- ======= BEGIN DATATABLE SCRIPTS ======= -->
 <!-- <script src="{{ asset('assets/js/jquery-3.6.0.min.js') }}" type="text/javascript"></script> -->
 
<!-- <script src="cdn.datatables.net/1.10.7/css/jquery.dataTables.min.css"></script>
<script src="cdn.datatables.net/1.10.7/js/jquery.dataTables.min.js"></script>  -->

</body>
</html>